package com.example.securitydemo.model.enums;

public enum UserRoleEnum {
    ADMIN,
    MODERATOR
}
